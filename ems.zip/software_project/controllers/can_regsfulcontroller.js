const getcan_regsful = (req,res) => {
    res.render("cand_registrationsuccesful");
}

module.exports = {
    getcan_regsful
};
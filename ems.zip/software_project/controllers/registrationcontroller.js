const getRegistration = (req,res) => {
    res.render("registration");
}

module.exports = {
    getRegistration
};
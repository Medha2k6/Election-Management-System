const getHome = (req,res) => {
    res.render("homepage");
}

module.exports = {
    getHome
};
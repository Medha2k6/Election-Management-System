const getvoter_registrationsucces = (req,res) => {
    res.render("voter_registrationsucces");
}

module.exports = {
    getvoter_registrationsucces
};